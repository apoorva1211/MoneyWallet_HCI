# Expense-Manager
A daily expense tracker created to help users maintain expenses and add monthly budgets. It also displays a graphical representation of expenses categorywise. 
